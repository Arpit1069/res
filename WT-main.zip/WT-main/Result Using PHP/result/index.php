<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
    <div class="container">
        <h1>Welcome to VIT Semester Results</h1>
        <div class="btn-container">
            <a href="teacher.php" class="btn teacher-btn">Teacher</a>
            <a href="student.php" class="btn student-btn">Student</a>
        </div>
    </div>
</body>
</html>
