# Web Technology 

### Mini problem statements
This directory contains all the mini problem statements that I have solved during my web technology course. <br>
All problem statements have a database and other files that are required to run the code.

### Problem statement uses the following technologies:
```css
Frontend : HTML, CSS, React, JavaScript, Bootstrap, JQuery
```

```css
Backend : Php, Node.js, Spring Boot, JavaScript, Django, Ajax
```

```css
Databases : Mysql, MongoDB, JSON Files
```

Look at the problem statements file and find the corresponding folder to find the code for the problem statement.
