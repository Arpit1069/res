
<?php
$servername="localhost";
$username="root";
$password="";
$db = "mysql:host=localhost;dbname=employees;charset=utf8";
$pdo=new PDO($db,$username,$password);
?>
